<?php
function SyncData()
{
    require($_SERVER['DOCUMENT_ROOT'] . '/auth.php');
    sleep(3);
    require($_SERVER['DOCUMENT_ROOT'] . '/contacts.php');
    sleep(3);
    require($_SERVER['DOCUMENT_ROOT'] . '/buyers.php');
    sleep(3);
    require($_SERVER['DOCUMENT_ROOT'] . '/CUSTOMFIELDS_BUYERS.php');
    sleep(3);
    require($_SERVER['DOCUMENT_ROOT'] . '/leads.php');
    sleep(3);
    require($_SERVER['DOCUMENT_ROOT'] . '/CUSTOMFIELDS_LEADS.php');
    sleep(3);
    require($_SERVER['DOCUMENT_ROOT'] . '/pipeline.php');
    sleep(3);
    require($_SERVER['DOCUMENT_ROOT'] . '/transactions.php');
}
<?php

/**
 * Front to the WordPress application. This file doesn't do anything, but loads
 * wp-blog-header.php which does and tells WordPress to load the theme.
 *
 * @package WordPress
 */

/**
 * Tells WordPress to load the WordPress theme and output it.
 *
 * @var bool
 */
#define( 'WP_USE_THEMES', true );

/** Loads the WordPress Environment and Template */
require( dirname( __FILE__ ) . '/wp-blog-header.php' );
$out = $_POST;
$Response = $out['contacts']['update'];

// чтение config.ini
$status_const = parse_ini_file($_SERVER['DOCUMENT_ROOT'] . "/config.ini");
$servername = $status_const['servername'];
$database = $status_const['database'];
$username = $status_const['username'];
$password = $status_const['password'];
// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);
// Check connection
if (!$conn) {
    $content = "CONTACTS update Connection failed: ".date('h:i:s') . ' Код: '. mysqli_connect_error() . "\n";
    $fp = fopen($_SERVER['DOCUMENT_ROOT'] . "/log.txt","a");
    fwrite($fp, $content);
    fclose($fp);
    die("CONTACTS update Connection failed: " . mysqli_connect_error());
}
else {
//write to log.txt 'CONTACTS Connected successfully';
    $content = "CONTACTS update Connected successfully ".date('h:i:s') ."\n";
    $fp = fopen($_SERVER['DOCUMENT_ROOT'] . "/log.txt","a");
    fwrite($fp, $content);
    fclose($fp);}
//Обработка ответа
foreach ($Response as $v) {
    if (is_array($v)) {
        $id = $v['id'];
        $name = $v['name'] . PHP_EOL;
        $responsible_user_id = $v['responsible_user_id'];
        // $custom_fields = $v['custom_fields'];
        $psyholog_flag = 0;
        $is_deleted_flag = 0;

        foreach ($custom_fields as $i) {
            if (is_array($i)) {
                $psyholog = $i['name'];
                if ($psyholog == 'Психолог') {
                    $psyholog_flag_v = $i['values'];
                }
            }
        }

        foreach ($psyholog_flag_v as $i) {
            if (is_array($i)) {
                $psyholog_flag = $i['value'];
            }
        }
        if ($psyholog_flag == '') {
            $psyholog_flag = 0;
        }
        foreach ($custom_fields as $i) {
            if (is_array($i)) {
                $is_deleted = $i['name'];
                if ($is_deleted == 'is_deleted') {
                    $is_deleted_flag_v = $i['values'];
                }
            }
        }

        foreach ($is_deleted_flag_v as $i) {
            if (is_array($i)) {
                $is_deleted_flag = $i['value'];
            }
        }
        if ($is_deleted_flag == '') {
            $is_deleted_flag = 0;
        }
        $sql = "UPDATE CONTACTS SET responsible_user_id='$responsible_user_id', name='$name', psyholog= '$psyholog_flag', is_deleted='$is_deleted_flag' WHERE id = $id";
        if (mysqli_query($conn, $sql)) {
            $content = "Запись update в таблицу CONTACTS удалась ".date('h:i:s') ."\n";
            $fp = fopen($_SERVER['DOCUMENT_ROOT'] . "/log.txt","a");
            fwrite($fp, $content);
            fclose($fp);
        } else {
            $content = "Запись update в таблицу CONTACTS не удалась ".date('h:i:s') . ' Код: '. mysqli_error($conn) . "\n";
            $fp = fopen($_SERVER['DOCUMENT_ROOT'] . "/log.txt","a");
            fwrite($fp, $content);
            fclose($fp);
        }
    }
}
mysqli_close($conn);

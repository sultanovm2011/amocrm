<?php

/**
 * Front to the WordPress application. This file doesn't do anything, but loads
 * wp-blog-header.php which does and tells WordPress to load the theme.
 *
 * @package WordPress
 */

/**
 * Tells WordPress to load the WordPress theme and output it.
 *
 * @var bool
 */
#define( 'WP_USE_THEMES', true );

/** Loads the WordPress Environment and Template */
require( dirname( __FILE__ ) . '/wp-blog-header.php' );
$out = $_POST;
$Response = $out['contacts']['delete'];

// чтение config.ini
$status_const = parse_ini_file($_SERVER['DOCUMENT_ROOT'] . "/config.ini");
$servername = $status_const['servername'];
$database = $status_const['database'];
$username = $status_const['username'];
$password = $status_const['password'];
// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);
// Check connection
if (!$conn) {
    $content = "BUYERS delete Connection failed: ".date('h:i:s') . ' Код: '. mysqli_connect_error() . "\n";
    $fp = fopen($_SERVER['DOCUMENT_ROOT'] . "/log.txt","a");
    fwrite($fp, $content);
    fclose($fp);
    die("BUYERS delete Connection failed: " . mysqli_connect_error());
}
else {
//write to log.txt 'BUYERS Connected successfully';
    $content = "BUYERS delete Connected successfully ".date('h:i:s') ."\n";
    $fp = fopen($_SERVER['DOCUMENT_ROOT'] . "/log.txt","a");
    fwrite($fp, $content);
    fclose($fp);}
//Обработка ответа
foreach ($Response as $v) {
    if (is_array($v)) {
        $id = $v['id'];
        $is_deleted = 1;
        $sql = "UPDATE BUYERS SET is_deleted='$is_deleted'  WHERE id = $id";
        if (mysqli_query($conn, $sql)) {
            $content = "Запись delete в таблицу BUYERS удалась ".date('h:i:s') ."\n";
            $fp = fopen($_SERVER['DOCUMENT_ROOT'] . "/log.txt","a");
            fwrite($fp, $content);
            fclose($fp);
        } else {
            $content = "Запись delete в таблицу BUYERS не удалась ".date('h:i:s') . ' Код: '. mysqli_error($conn) . "\n";
            $fp = fopen($_SERVER['DOCUMENT_ROOT'] . "/log.txt","a");
            fwrite($fp, $content);
            fclose($fp);
        }
    }
}
mysqli_close($conn);
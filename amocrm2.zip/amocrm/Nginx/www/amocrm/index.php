<?php
function SyncData()
{
    require($_SERVER['DOCUMENT_ROOT'] . '/auth.php');
    sleep(30);
    require($_SERVER['DOCUMENT_ROOT'] . '/contacts.php');
    sleep(300);
    require($_SERVER['DOCUMENT_ROOT'] . '/buyers.php');
    sleep(300);
    require($_SERVER['DOCUMENT_ROOT'] . '/CUSTOMFIELDS_BUYERS.php');
    sleep(300);
    require($_SERVER['DOCUMENT_ROOT'] . '/leads.php');
    sleep(300);
    require($_SERVER['DOCUMENT_ROOT'] . '/CUSTOMFIELDS_LEADS.php');
    sleep(300);
    require($_SERVER['DOCUMENT_ROOT'] . '/pipeline.php');
//    sleep(300);
//    require($_SERVER['DOCUMENT_ROOT'] . '/transactions.php');
}
SyncData();